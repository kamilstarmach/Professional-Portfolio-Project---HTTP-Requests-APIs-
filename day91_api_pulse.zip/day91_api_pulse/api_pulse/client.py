"""Small, testable clients for public HTTP APIs."""

from typing import Any
import requests

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
JOKE_URL = "https://official-joke-api.appspot.com/jokes/programming/random"


class APIError(RuntimeError):
    """Raised when an API request fails or returns unusable data."""


def _get_json(url: str, params: dict[str, Any] | None = None) -> Any:
    """Request JSON from an endpoint with timeout and useful error handling."""
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as exc:
        raise APIError(f"Request failed: {exc}") from exc
    except ValueError as exc:
        raise APIError("The API returned invalid JSON.") from exc


def find_city(city: str) -> dict[str, Any]:
    """Return the best geocoding match for a city name."""
    city = city.strip()
    if not city:
        raise APIError("Please enter a city name.")
    data = _get_json(GEOCODING_URL, {
        "name": city, "count": 1, "language": "en", "format": "json"
    })
    results = data.get("results") or []
    if not results:
        raise APIError(f"No location found for '{city}'.")
    return results[0]


def get_current_weather(latitude: float, longitude: float) -> dict[str, Any]:
    """Fetch current temperature and wind speed for coordinates."""
    data = _get_json(FORECAST_URL, {
        "latitude": latitude,
        "longitude": longitude,
        "current": "temperature_2m,wind_speed_10m",
    })
    current = data.get("current")
    if not isinstance(current, dict):
        raise APIError("Weather data was missing from the API response.")
    return current


def get_programming_joke() -> str:
    """Return a random programming joke."""
    data = _get_json(JOKE_URL)
    if not isinstance(data, list) or not data:
        raise APIError("The joke API returned no jokes.")
    joke = data[0]
    setup = joke.get("setup", "").strip()
    punchline = joke.get("punchline", "").strip()
    if not setup or not punchline:
        raise APIError("The joke API returned an incomplete joke.")
    return f"{setup}\n{punchline}"
