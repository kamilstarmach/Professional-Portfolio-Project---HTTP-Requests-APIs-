# API Pulse — HTTP Requests & APIs

**Day 91 — Professional Portfolio Project | 100 Days of Code**

API Pulse is a command-line dashboard that consumes public HTTP APIs. It fetches a city's current weather from Open-Meteo and a random programming joke from the Official Joke API.

## Features
- HTTP GET requests using `requests`
- Query parameters and JSON response handling
- Error handling for timeouts, HTTP errors, and invalid responses
- City lookup through Open-Meteo geocoding
- Current weather display
- Random programming joke
- Unit tests with mocked HTTP responses

## Requirements
- Python 3.10+
- Internet connection to fetch live API data

## Setup

```bash
git clone https://github.com/yourusername/api-pulse.git
cd api-pulse
python -m venv .venv
```

Activate the environment:

**Windows PowerShell**
```powershell
.venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

Install and run:

```bash
pip install -r requirements.txt
python main.py
```

Enter a city when prompted.

## Run tests

```bash
python -m unittest discover -s tests -v
```

Tests mock network calls and do not require internet access.

## Project structure

```text
day91_api_pulse/
├── api_pulse/
│   ├── __init__.py
│   └── client.py
├── tests/
│   └── test_client.py
├── main.py
├── requirements.txt
├── README.md
└── .gitignore
```

## APIs
- [Open-Meteo Geocoding](https://geocoding-api.open-meteo.com/)
- [Open-Meteo Forecast](https://open-meteo.com/en/docs)
- [Official Joke API](https://official-joke-api.appspot.com/)

## Future improvements
- Add a Tkinter GUI
- Cache responses
- Export results to JSON
- Add retry logic and weather-code descriptions

## Author
Created as part of the **100 Days of Code: Python Bootcamp**.
