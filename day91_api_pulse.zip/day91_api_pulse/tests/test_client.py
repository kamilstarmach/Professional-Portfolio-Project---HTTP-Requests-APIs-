import unittest
from unittest.mock import Mock, patch
import requests

from api_pulse.client import (
    APIError, GEOCODING_URL, JOKE_URL, find_city,
    get_programming_joke, _get_json
)


class APIClientTests(unittest.TestCase):
    @patch("api_pulse.client.requests.get")
    def test_find_city_returns_first_result(self, mock_get):
        response = Mock()
        response.json.return_value = {
            "results": [{"name": "Berlin", "latitude": 52.52, "longitude": 13.405}]
        }
        response.raise_for_status.return_value = None
        mock_get.return_value = response
        city = find_city("Berlin")
        self.assertEqual(city["name"], "Berlin")
        self.assertEqual(mock_get.call_args.args[0], GEOCODING_URL)

    @patch("api_pulse.client.requests.get")
    def test_find_city_raises_when_no_results(self, mock_get):
        response = Mock()
        response.json.return_value = {"results": []}
        response.raise_for_status.return_value = None
        mock_get.return_value = response
        with self.assertRaises(APIError):
            find_city("No Such City")

    @patch("api_pulse.client.requests.get")
    def test_joke_is_combined(self, mock_get):
        response = Mock()
        response.json.return_value = [{"setup": "Why?", "punchline": "Because."}]
        response.raise_for_status.return_value = None
        mock_get.return_value = response
        self.assertEqual(get_programming_joke(), "Why?\nBecause.")
        self.assertEqual(mock_get.call_args.args[0], JOKE_URL)

    @patch("api_pulse.client.requests.get")
    def test_http_error_is_wrapped(self, mock_get):
        mock_get.side_effect = requests.Timeout("timed out")
        with self.assertRaises(APIError):
            _get_json("https://example.com")


if __name__ == "__main__":
    unittest.main()
