"""Command-line entry point for API Pulse."""

from api_pulse.client import (
    APIError, find_city, get_current_weather, get_programming_joke
)


def main() -> None:
    print("=" * 50)
    print("API PULSE | HTTP Requests & APIs")
    print("=" * 50)
    city_input = input("Enter a city: ").strip()

    try:
        location = find_city(city_input)
        weather = get_current_weather(
            location["latitude"], location["longitude"]
        )
        joke = get_programming_joke()
        place = ", ".join(
            part for part in (
                location.get("name"), location.get("admin1"),
                location.get("country")
            ) if part
        )
        print(f"\nCity: {place}")
        print("\nWEATHER")
        print(f"Temperature: {weather.get('temperature_2m', 'N/A')} °C")
        print(f"Wind speed: {weather.get('wind_speed_10m', 'N/A')} km/h")
        print("\nPROGRAMMING JOKE")
        print(joke)
        print("\nDone. Data retrieved from public APIs.")
    except APIError as error:
        print(f"\nCould not retrieve data: {error}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
